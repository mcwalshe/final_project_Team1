package org.speed_reader.gui;

public class Test_Driver {

	public static void main(String[] args) {
		// Instantiate GUI
		MainGUI newGUI;
	    newGUI = new MainGUI();
	}
}
